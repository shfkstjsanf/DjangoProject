
======== image resource from pixabay ========

* https://pixabay.com/en/manuplation-flowers-beautiful-girl-1953216/
 -person01.jpg

* https://pixabay.com/en/person-human-female-girl-face-864804/
- person02.jpg

* https://pixabay.com/en/person-human-female-girl-winter-1188508/
- person03.jpng

* https://pixabay.com/en/child-portrait-girl-model-young-1871104/
- person04.jpg

* https://pixabay.com/en/baby-child-toddler-looking-girl-933097/
- person05.png



======== sample ========
* https://pixabay.com/en/pine-plant-tree-branch-needles-1884335/
- sample001.jpg

* https://pixabay.com/en/iceland-arctic-fox-animal-wildlife-1979445/
- sample002.jpg

* https://pixabay.com/en/hot-air-balloons-floating-fun-1984308/
- sample003.jpg

* https://pixabay.com/en/heart-sweetheart-leaf-autumn-maple-1776746/
- sample004.jpg

* https://pixabay.com/en/moon-the-fullness-of-sky-mystery-1859616/
- sample005.jpg

* https://pixabay.com/en/dahlia-flower-composites-1574428/
- sample006.jpg

* https://pixabay.com/en/background-bitter-breakfast-bright-1239267/
- sample007.jpg

* https://pixabay.com/en/wave-atlantic-pacific-ocean-huge-1913559/
- sample008.jpg

* https://pixabay.com/en/lake-sky-reflection-water-clouds-1611044/
- sample009.jpg

* https://pixabay.com/en/sunset-sun-abendstimmung-1122188/
- sample010.jpg

* https://pixabay.com/en/sun-sunset-abendstimmung-yellow-439440/
- sample011.jpg


======== sticker ========
* https://openclipart.org/detail/27527/glasses
- sticker_eye_001.png

* https://openclipart.org/detail/188895/cartoon-eyes
- sticker_eye_002.png



* https://openclipart.org/detail/185281/a-smiling-mouth
- sticker_mouth_001.png

* https://openclipart.org/detail/14588/mouth-with-tongue
- sticker_mouth_002.png



* https://openclipart.org/detail/202547/nose-2-colored
- sticker_nose_001.png




